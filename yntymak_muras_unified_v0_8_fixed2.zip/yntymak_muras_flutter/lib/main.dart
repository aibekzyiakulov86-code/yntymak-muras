import 'package:flutter/material.dart';

void main() => runApp(const YntymakMurasApp());

class YntymakMurasApp extends StatelessWidget {
  const YntymakMurasApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Ынтымак Мурас',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFFFFB800), scaffoldBackgroundColor: const Color(0xFFF7F7F7)),
        home: const RoleChooserPage(),
      );
}

class RoleChooserPage extends StatelessWidget {
  const RoleChooserPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text('ЫНТЫМАК МУРАС', style: TextStyle(fontWeight: FontWeight.w900)),
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const SizedBox(height: 18),
              const Icon(Icons.local_taxi, size: 72, color: Color(0xFFFFB800)),
              const SizedBox(height: 12),
              const Text('Выберите режим', textAlign: TextAlign.center, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('Сейчас все режимы находятся в одном приложении. Позже их можно разделить на отдельные приложения.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 24),
              _RoleCard(icon: Icons.person, title: 'Пассажир', subtitle: 'Такси, доставка, портер и история поездок', onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage()))),
              _RoleCard(icon: Icons.drive_eta, title: 'Водитель', subtitle: 'Заказы, поездки, заработок и рейтинг', onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DriverPage()))),
              _RoleCard(icon: Icons.admin_panel_settings, title: 'Администратор', subtitle: 'Заказы, водители, пользователи и статистика', onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminPage()))),
            ],
          ),
        ),
      );
}

class _RoleCard extends StatelessWidget {
  const _RoleCard({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 14),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              CircleAvatar(radius: 28, child: Icon(icon, size: 30)),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.black54))])),
              const Icon(Icons.chevron_right),
            ]),
          ),
        ),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tariff = 0;
  int service = 0;
  String payment = 'Наличные';
  String destination = 'Выберите адрес';
  bool favoriteHome = false;
  String parcelSize = 'Маленькая';
  String recipient = '';
  String porterWeight = 'до 500 кг';
  String porterVehicle = 'Спринтер';
  int porterHelpers = 1;
  final services = const [('Такси', Icons.local_taxi), ('Доставка', Icons.inventory_2), ('Портер', Icons.local_shipping)];
  final tariffs = const [('Эконом', 150, '3–5 мин', Icons.directions_car), ('Комфорт', 200, '4–6 мин', Icons.airline_seat_recline_normal), ('Минивэн', 300, '5–8 мин', Icons.airport_shuttle)];

  void order() {
    final names = ['Такси', 'Доставка', 'Портер'];
    final base = tariffs[tariff].$2;
    final price = service == 0 ? base : service == 1 ? base + 100 : base + 250;
    final details = service == 1 ? 'Посылка: $parcelSize · Получатель: ${recipient.isEmpty ? 'не указан' : recipient}' : 'Вес: $porterWeight · $porterVehicle · Грузчиков: $porterHelpers';
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => DriverSearchSheet(tariff: names[service], price: price, payment: payment, details: details));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ЫНТЫМАК МУРАС', style: TextStyle(fontWeight: FontWeight.w900)), actions: [IconButton(tooltip: 'Сменить режим', onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const RoleChooserPage())), icon: const Icon(Icons.swap_horiz)), IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfilePage())), icon: const Icon(Icons.person_outline))]),
        body: SafeArea(child: Column(children: [
          Expanded(child: Stack(children: [
            Container(margin: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFE5E0D4), borderRadius: BorderRadius.circular(24)), child: Stack(children: [
              const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.map, size: 52, color: Color(0xFFFFB800)), Text('Карта Кара-Куля', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), Text('Местоположение определяется автоматически')])),
              Positioned(top: 20, right: 20, child: FloatingActionButton.small(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Местоположение обновлено'))), child: const Icon(Icons.my_location))),
            ])),
            Positioned(left: 24, right: 24, bottom: 24, child: Card(elevation: 6, child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
              InkWell(onTap: () => _pickAddress(context, true), child: const Row(children: [Icon(Icons.my_location, color: Colors.blue), SizedBox(width: 12), Expanded(child: Text('Откуда\nМоё местоположение', style: TextStyle(fontWeight: FontWeight.w700)))])),
              const Divider(height: 22),
              InkWell(onTap: () => _pickAddress(context, false), child: Row(children: [const Icon(Icons.location_on, color: Colors.redAccent), const SizedBox(width: 12), Expanded(child: Text('Куда едем?\n')) , Text(destination, style: const TextStyle(fontWeight: FontWeight.w600)), const Icon(Icons.chevron_right)])),
              const SizedBox(height: 8),
              Row(children: [Icon(favoriteHome ? Icons.favorite : Icons.favorite_border, size: 20), const SizedBox(width: 8), const Text('Избранные адреса'), const Spacer(), TextButton(onPressed: () => setState(() => favoriteHome = !favoriteHome), child: Text(favoriteHome ? 'Дом сохранён' : 'Сохранить'))])
            ]))))
          ])),
          SizedBox(
            height: 88,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: services.length,
              itemBuilder: (_, i) {
                final x = services[i];
                final selected = i == service;
                return GestureDetector(
                  onTap: () => setState(() => service = i),
                  child: Container(
                    width: 145,
                    margin: const EdgeInsets.all(5),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: selected ? const Color(0xFFFFF2C8) : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: selected ? const Color(0xFFFFB800) : Colors.black12,
                        width: selected ? 2 : 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(x.$2, size: 28),
                        const SizedBox(width: 10),
                        Text(
                          x.$1,
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          if (service == 1) _deliveryOptions(),
          if (service == 2) _porterOptions(),
          SizedBox(
            height: 110,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: tariffs.length,
              itemBuilder: (_, i) {
                final t = tariffs[i];
                final selected = i == tariff;
                return GestureDetector(
                  onTap: () => setState(() => tariff = i),
                  child: Container(
                    width: 150,
                    margin: const EdgeInsets.all(5),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: selected ? const Color(0xFFFFF2C8) : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: selected ? const Color(0xFFFFB800) : Colors.black12,
                        width: selected ? 2 : 1,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(t.$4, size: 22),
                        const Spacer(),
                        Text(
                          t.$1,
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        Text(
                          '${t.$2} сом · ${t.$3}',
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 18),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _choosePayment,
                    icon: const Icon(Icons.payments_outlined),
                    label: Text(payment),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SizedBox(
                    height: 52,
                    child: FilledButton(
                      onPressed: order,
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFFFFB800),
                        foregroundColor: Colors.black,
                      ),
                      child: const Text(
                        'ЗАКАЗАТЬ',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ])),
        bottomNavigationBar: NavigationBar(selectedIndex: 0, onDestinationSelected: (i) { if (i == 1) Navigator.push(context, MaterialPageRoute(builder: (_) => const TripsPage())); if (i == 2) Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverPage())); if (i == 3) Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfilePage())); }, destinations: const [NavigationDestination(icon: Icon(Icons.local_taxi), label: 'Такси'), NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Поездки'), NavigationDestination(icon: Icon(Icons.drive_eta), label: 'Водитель'), NavigationDestination(icon: Icon(Icons.person), label: 'Профиль')]),
      );

  Widget _deliveryOptions() => Card(margin: const EdgeInsets.fromLTRB(12, 2, 12, 6), child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Row(children: const [Icon(Icons.inventory_2), SizedBox(width: 8), Text('Доставка', style: TextStyle(fontWeight: FontWeight.w900)), Spacer(), Text('Параметры')]), const SizedBox(height: 8), Row(children: [Expanded(child: DropdownButtonFormField<String>(value: parcelSize, decoration: const InputDecoration(labelText: 'Размер посылки', border: OutlineInputBorder()), items: ['Маленькая', 'Средняя', 'Большая'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (x) => setState(() => parcelSize = x!))), const SizedBox(width: 8), Expanded(child: TextFormField(initialValue: recipient, decoration: const InputDecoration(labelText: 'Получатель', border: OutlineInputBorder()), onChanged: (x) => recipient = x))])])));

  Widget _porterOptions() => Card(margin: const EdgeInsets.fromLTRB(12, 2, 12, 6), child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Row(children: const [Icon(Icons.local_shipping), SizedBox(width: 8), Text('Портер', style: TextStyle(fontWeight: FontWeight.w900)), Spacer(), Text('Параметры')]), const SizedBox(height: 8), Row(children: [Expanded(child: DropdownButtonFormField<String>(value: porterWeight, decoration: const InputDecoration(labelText: 'Вес', border: OutlineInputBorder()), items: ['до 500 кг', 'до 1 тонны', 'до 3 тонн'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (x) => setState(() => porterWeight = x!))), const SizedBox(width: 8), Expanded(child: DropdownButtonFormField<String>(value: porterVehicle, decoration: const InputDecoration(labelText: 'Машина', border: OutlineInputBorder()), items: ['Спринтер', 'Бортовая', 'Грузовик'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (x) => setState(() => porterVehicle = x!))]), const SizedBox(height: 8), Row(children: [const Text('Грузчики', style: TextStyle(fontWeight: FontWeight.w700)), const Spacer(), IconButton(onPressed: porterHelpers > 1 ? () => setState(() => porterHelpers--) : null, icon: const Icon(Icons.remove_circle_outline)), Text('$porterHelpers', style: const TextStyle(fontWeight: FontWeight.w900)), IconButton(onPressed: porterHelpers < 4 ? () => setState(() => porterHelpers++) : null, icon: const Icon(Icons.add_circle_outline))])])));

  void _pickAddress(BuildContext context, bool from) async { final value = await showDialog<String>(context: context, builder: (_) => SimpleDialog(title: Text(from ? 'Откуда?' : 'Куда едем?'), children: ['Дом', 'Работа', 'Центр Кара-Куля', 'Вокзал', 'Другое'].map((x) => SimpleDialogOption(onPressed: () => Navigator.pop(context, x), child: Text(x))).toList())); if (!from && value != null) setState(() => destination = value); }
  void _choosePayment() { showModalBottomSheet(context: context, builder: (_) => Column(mainAxisSize: MainAxisSize.min, children: ['Наличные', 'Элсом', 'Мбанк', 'Банковская карта'].map((x) => ListTile(leading: const Icon(Icons.payment), title: Text(x), onTap: () { setState(() => payment = x); Navigator.pop(context); })).toList())); }
}

class DriverSearchSheet extends StatefulWidget { const DriverSearchSheet({super.key, required this.tariff, required this.price, required this.payment, required this.details}); final String tariff; final int price; final String payment; final String details; @override State<DriverSearchSheet> createState() => _DriverSearchSheetState(); }
class _DriverSearchSheetState extends State<DriverSearchSheet> { bool found = false; @override void initState() { super.initState(); Future.delayed(const Duration(seconds: 2), () { if (mounted) setState(() => found = true); }); }
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(found ? Icons.check_circle : Icons.radar, size: 64, color: found ? Colors.green : const Color(0xFFFFB800)), const SizedBox(height: 12), Text(found ? 'Водитель найден!' : 'Ищем ближайшего водителя…', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text('${widget.tariff} · ${widget.price} сом · ${widget.payment}'), const SizedBox(height: 4), Text(widget.details, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.black54)), const SizedBox(height: 18), if (found) Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: const Text('Нурбек · Toyota Prius', style: TextStyle(fontWeight: FontWeight.bold)), subtitle: const Text('⭐ 4.9 · 3 минуты · KG 777 AAA'), trailing: IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Звонок водителю…'))), icon: const Icon(Icons.call)))), if (found) Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () => _chat(context), icon: const Icon(Icons.chat), label: const Text('Чат'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: () => _ride(context), child: const Text('НАЧАТЬ ПОЕЗДКУ')))]), const SizedBox(height: 8)]));
  void _chat(BuildContext c) => showDialog(context: c, builder: (_) => AlertDialog(title: const Text('Чат с Нурбеком'), content: const Text('Водитель: Здравствуйте! Я уже подъезжаю.'), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Закрыть'))]));
  void _ride(BuildContext c) { Navigator.pop(c); showDialog(context: c, builder: (_) => const RatingDialog()); }
}

class RatingDialog extends StatefulWidget { const RatingDialog({super.key}); @override State<RatingDialog> createState() => _RatingDialogState(); }
class _RatingDialogState extends State<RatingDialog> { int rating = 5; @override Widget build(BuildContext context) => AlertDialog(title: const Text('Поездка завершена'), content: Column(mainAxisSize: MainAxisSize.min, children: [const Text('Оцените водителя'), Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(5, (i) => IconButton(onPressed: () => setState(() => rating = i + 1), icon: Icon(Icons.star, color: i < rating ? Colors.amber : Colors.grey)))), const Text('Чек: 150 сом · 12 мин · 4.8 км'), const SizedBox(height: 8), OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.receipt_long), label: const Text('Получить чек'))]), actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Готово'))]); }

class TripsPage extends StatelessWidget { const TripsPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('История поездок')), body: ListView(padding: const EdgeInsets.all(16), children: const [TripTile('Сегодня, 18:20', 'Дом → Центр Кара-Куля', '150 сом', 'Завершена'), TripTile('Вчера, 10:15', 'Вокзал → Работа', '200 сом', 'Завершена'), TripTile('10 августа, 21:30', 'Центр → Дом', '150 сом', 'Завершена')])); }
class TripTile extends StatelessWidget { const TripTile(this.date, this.route, this.price, this.status, {super.key}); final String date, route, price, status; @override Widget build(BuildContext context) => Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.local_taxi)), title: Text(route, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('$date · $status'), trailing: Text(price, style: const TextStyle(fontWeight: FontWeight.w900)))); }

class ProfilePage extends StatelessWidget { const ProfilePage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Профиль')), body: ListView(padding: const EdgeInsets.all(16), children: [const Card(child: ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('Айбек'), subtitle: Text('+996 ••• ••• •••'))), ListTile(leading: const Icon(Icons.phone), title: const Text('Вход по номеру телефона'), trailing: const Icon(Icons.chevron_right), onTap: () => _login(context)), ListTile(leading: const Icon(Icons.notifications), title: const Text('Уведомления'), trailing: Switch(value: true, onChanged: (_) {})), ListTile(leading: const Icon(Icons.language), title: const Text('Язык'), subtitle: const Text('Русский / Кыргызча')), ListTile(leading: const Icon(Icons.card_giftcard), title: const Text('Промокод и бонусы'), onTap: () => showDialog(context: context, builder: (_) => const PromoDialog())), ListTile(leading: const Icon(Icons.shield), title: const Text('Безопасность поездки')), ListTile(leading: const Icon(Icons.admin_panel_settings), title: const Text('Админ-панель'), subtitle: const Text('Заказы, водители, пользователи и статистика'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage()))), ListTile(leading: const Icon(Icons.sos, color: Colors.red), title: const Text('SOS — экстренная помощь', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)), onTap: () => showDialog(context: context, builder: (_) => const AlertDialog(title: Text('SOS'), content: Text('Экстренная функция подготовлена. В рабочей версии подключим службы помощи и доверенные контакты.')))])); }
  void _login(BuildContext c) => showDialog(context: c, builder: (_) => const AlertDialog(title: Text('Вход'), content: TextField(decoration: InputDecoration(labelText: 'Номер телефона', prefixText: '+996 ')), actions: [TextButton(onPressed: null, child: Text('Получить код'))])); }
class PromoDialog extends StatelessWidget { const PromoDialog({super.key}); @override Widget build(BuildContext context) => AlertDialog(title: const Text('Промокод'), content: const TextField(decoration: InputDecoration(hintText: 'Введите промокод')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Применить'))]); }

class DriverPage extends StatelessWidget { const DriverPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Режим водителя'), actions: [IconButton(tooltip: 'Сменить режим', onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const RoleChooserPage())), icon: const Icon(Icons.swap_horiz))]), body: ListView(padding: const EdgeInsets.all(16), children: [Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.drive_eta)), title: const Text('Вы на линии'), subtitle: const Text('Получайте новые заказы'), trailing: Switch(value: true, onChanged: (_) {}))), Card(child: Column(children: const [ListTile(leading: Icon(Icons.payments), title: Text('Заработок сегодня'), trailing: Text('2 450 сом', style: TextStyle(fontWeight: FontWeight.w900))), ListTile(leading: Icon(Icons.route), title: Text('Поездок'), trailing: Text('12')), ListTile(leading: Icon(Icons.star), title: Text('Рейтинг'), trailing: Text('4.9'))])), const SizedBox(height: 10), Card(child: ListTile(leading: const Icon(Icons.notifications_active), title: const Text('Новый заказ'), subtitle: const Text('Центр → Вокзал · 180 сом'), trailing: FilledButton(onPressed: () {}, child: const Text('Принять')))), ListTile(leading: const Icon(Icons.account_balance_wallet), title: const Text('Баланс и выплаты')), ListTile(leading: const Icon(Icons.history), title: const Text('История заказов'))])); }


class AdminPage extends StatefulWidget {
  const AdminPage({super.key});
  @override State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  int tab = 0;
  final orders = const [
    ('#1042', 'Такси', 'Дом → Центр', '150 сом', 'В пути'),
    ('#1041', 'Доставка', 'Вокзал → ул. Ленина', '250 сом', 'Ищет водителя'),
    ('#1040', 'Портер', 'Рынок → Дом', '900 сом', 'Завершён'),
  ];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Админ-панель', style: TextStyle(fontWeight: FontWeight.w900)), actions: [IconButton(tooltip: 'Сменить режим', onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const RoleChooserPage())), icon: const Icon(Icons.swap_horiz)), IconButton(onPressed: () => setState(() {}), icon: const Icon(Icons.refresh))]),
    body: ListView(padding: const EdgeInsets.all(14), children: [
      const Card(child: Padding(padding: EdgeInsets.all(14), child: Row(children: [CircleAvatar(child: Icon(Icons.admin_panel_settings)), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Администратор', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)), Text('Система работает нормально')]))]))),
      const SizedBox(height: 8),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.7, children: const [
        AdminStat('Заказы сегодня', '128', Icons.receipt_long), AdminStat('Водители онлайн', '34', Icons.drive_eta), AdminStat('Пользователи', '1 842', Icons.people), AdminStat('Выручка сегодня', '86 400 сом', Icons.payments),
      ]),
      const SizedBox(height: 10),
      Card(child: Column(children: [const ListTile(title: Text('Быстрые действия', style: TextStyle(fontWeight: FontWeight.w900))),
        ListTile(leading: const Icon(Icons.person_add), title: const Text('Добавить водителя'), trailing: const Icon(Icons.chevron_right), onTap: () => _message('Форма добавления водителя открыта')),
        ListTile(leading: const Icon(Icons.local_offer), title: const Text('Создать промокод'), trailing: const Icon(Icons.chevron_right), onTap: () => _message('Форма промокода открыта')),
        ListTile(leading: const Icon(Icons.campaign), title: const Text('Отправить уведомление'), trailing: const Icon(Icons.chevron_right), onTap: () => _message('Форма уведомления открыта')),
      ])),
      const SizedBox(height: 10),
      Card(child: Column(children: [const ListTile(title: Text('Последние заказы', style: TextStyle(fontWeight: FontWeight.w900))), ...orders.map((o) => ListTile(leading: CircleAvatar(child: Icon(o.$2 == 'Портер' ? Icons.local_shipping : o.$2 == 'Доставка' ? Icons.inventory_2 : Icons.local_taxi)), title: Text('${o.$1} · ${o.$2}', style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${o.$3} · ${o.$5}'), trailing: Text(o.$4, style: const TextStyle(fontWeight: FontWeight.w900))))]))),
      const SizedBox(height: 10),
      Card(child: Column(children: [const ListTile(title: Text('Управление', style: TextStyle(fontWeight: FontWeight.w900))),
        _adminItem(Icons.people, 'Пользователи', '1 842 зарегистрировано'), _adminItem(Icons.drive_eta, 'Водители', '34 онлайн · 87 всего'), _adminItem(Icons.receipt_long, 'Все заказы', 'Просмотр и фильтры'), _adminItem(Icons.report_problem, 'Жалобы', '3 новых обращения'), _adminItem(Icons.settings, 'Настройки тарифов', 'Эконом, Комфорт, Минивэн'),
      ])),
    ]),
    bottomNavigationBar: NavigationBar(
      selectedIndex: tab,
      onDestinationSelected: (i) {
        setState(() {
          tab = i;
        });
      },
      destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard), label: 'Обзор'),
        NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Заказы'),
        NavigationDestination(icon: Icon(Icons.people), label: 'Люди'),
      ],
    ),
  );
  Widget _adminItem(IconData icon, String title, String sub) => ListTile(leading: Icon(icon), title: Text(title), subtitle: Text(sub), trailing: const Icon(Icons.chevron_right), onTap: () => _message('$title: раздел открыт'));
  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}

class AdminStat extends StatelessWidget {
  const AdminStat(this.title, this.value, this.icon, {super.key});
  final String title, value; final IconData icon;
  @override Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 24), const SizedBox(height: 6), Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54))])));
}
